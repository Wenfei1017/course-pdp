package edu.neu.ccs.cs5010;

public interface Size {
    public void accept(Visitor visitor);
}
