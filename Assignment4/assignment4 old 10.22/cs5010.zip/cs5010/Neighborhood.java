package edu.neu.ccs.cs5010;

public class Neighborhood {
    private Candy candy;
    private ChildVisitor childVisitor;
    private Mansion mansion;
    private Duplexe duplexe;
    private DetachedHouse detachedHouse;
    private TownHome townHome;

    public boolean findCandy(){
        boolean find = false;






        return find;
    }

}
