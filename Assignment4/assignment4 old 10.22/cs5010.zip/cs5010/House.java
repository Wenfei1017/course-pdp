package edu.neu.ccs.cs5010;

public interface House {
    public void accept(Visitor visitor);

}
