package edu.neu.ccs.cs5010;

import java.util.List;

public class HalloweenNeighborhoodTraversal {

    public void traversal(){
        List<Candy> dreamlist;
        CSVFileReader csvFileReader = new CSVFileReader();
        int childNum = Integer.parseInt(commandLine[childIndex]);


    }

}
