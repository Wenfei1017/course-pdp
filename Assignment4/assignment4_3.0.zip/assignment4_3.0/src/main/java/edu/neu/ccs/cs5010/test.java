package edu.neu.ccs.cs5010;

import java.util.ArrayList;
import java.util.List;

class Solution {
    public int[] nextGreaterElement(int[] nums1, int[] nums2) {
        int num1 = nums1.length;
        int num2 = nums2.length;
        int temp = 0;
        int[] num=new int[num1];
        int h = 0;
        for(int i = 0; i < num1; i++){
            temp = nums1[i];
            for(int j = 0; j < num2; j++){
                if(nums2[j]==temp) {
                    for (int k = j; k < num2; k++) {
                        if (nums2[k] > temp) {
                            num[i] = nums2[k];
                            break;
                        }
                    }
                }
            }
        }
        for(h = 0; h < num1; h++){
            if(num[h]==0){
                num[h] = -1;
            }
        }
        return num;
    }
}