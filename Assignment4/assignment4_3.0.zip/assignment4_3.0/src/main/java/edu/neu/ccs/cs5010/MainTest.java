package edu.neu.ccs.cs5010;

import java.io.FileNotFoundException;

public class MainTest {
    public static void main(String[] args) throws FileNotFoundException {

        HouseHold houseHold = new HouseHold();
        //houseHold.accept(new ChildVisitor());
        Visitor visitor = new ChildVisitor("DreamCandy1.csv");
        houseHold.accept(visitor);
    }
}
