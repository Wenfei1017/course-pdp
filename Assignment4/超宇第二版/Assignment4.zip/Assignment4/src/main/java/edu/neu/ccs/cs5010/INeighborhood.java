package edu.neu.ccs.cs5010;

/**
 * Created by wenfei on 10/22/17.
 */
public interface INeighborhood {
    void accept(INeighborhoodVisitor ineighborhoodVisitor);
}
