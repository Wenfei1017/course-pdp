package edu.neu.ccs.cs5010;

/**
 * Created by wenfei on 10/22/17.
 */
public interface ICandy {
    String getCandyName();
    String getCandySize();
    String getCandyHouse();

}
