package edu.neu.ccs.cs5010;

import static org.junit.Assert.*;

public class MyQueueTest {
    private MyQueue queue1;

    @org.junit.Before
    public void setUp() throws Exception {
        queue1 = new MyQueue();
    }

    @org.junit.Test
    public void enqueue() throws Exception {
        queue1.enqueue(4);
        queue1.enqueue(5);
    }

    @org.junit.Test
    public void dequeue() throws Exception {
        queue1.dequeue();
    }

    @org.junit.Test
    public void front() throws Exception {
        assertEquals(queue1.front(),5);

    }

    @org.junit.Test
    public void isEmpty() throws Exception {
        assertTrue(true);
    }

}