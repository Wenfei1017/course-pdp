package edu.neu.ccs.cs5010;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class MyStackTest {
    private MyStack stack1;

    @Before
    public void setUp() throws Exception {
        stack1 = new MyStack();
    }

    @Test
    public void push() throws Exception {
        stack1.push(4);
        stack1.push(7);
    }

    @Test
    public void pop() throws Exception {
        stack1.pop();
    }

    @Test
    public void top() throws Exception {
        assertEquals(stack1.top(),4);
    }

    @Test
    public void isEmpty() throws Exception {
        assertTrue(false);
    }

}