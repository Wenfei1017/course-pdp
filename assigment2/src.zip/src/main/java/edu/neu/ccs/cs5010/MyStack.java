package edu.neu.ccs.cs5010;
/**
 * Created by zontakm on 9/12/2017.
 * This is a dummy implementation of Stack ADT
 */
public class MyStack implements IStack {
    public IStack push(int elt) {return this;}
    public IStack pop() {return this;}
    public int top() {return 0;}
    public boolean isEmpty() {return true; }
}
