package edu.neu.ccs.cs5010;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

//I created this class because I want to save the message I created before, I think map and set should be moved to other parts

public class HashMapGenerator {
    private static HashMap<Client,RSAKeyPair> clientMap = new HashMap<>();
    private static HashMap<Client, RSAPrivateKey> privateKeyHashMap = new HashMap<>();
    //because the bank should only know the publickey, bank doesn't know the privte key
    //so bank should have this map to vesrify the signature
    private static HashMap<Client,RSAPublicKey> publicKeyHashMap = new HashMap<>();
    //private Client client;
    private static List<Client> clientList = new ArrayList<>();
    private static RSAPairCreator rsaPairCreator = new RSAPairCreator();

    public HashMap<Client,RSAKeyPair> creatMap() throws NoSuchAlgorithmException {
        //clientList = new ArrayList<>();
        for(Client thisclient:clientList) {
            clientMap.put(thisclient,rsaPairCreator.createKeys(thisclient));
        }return clientMap;
    }

    public static HashMap<Client, RSAPrivateKey> getPrivateKeyHashMap() throws NoSuchAlgorithmException {

        for(Client thisclient:clientList){
            privateKeyHashMap.put(thisclient, (RSAPrivateKey) rsaPairCreator.createKeys(thisclient).getPrivateKey());
        }
        return privateKeyHashMap;
    }

    public static HashMap<Client,RSAPublicKey> getPublicKeyHashMap() throws NoSuchAlgorithmException {

        for(Client thisclient:clientList){
            publicKeyHashMap.put(thisclient, rsaPairCreator.createKeys(thisclient).getPublicKey());
        }
        return publicKeyHashMap;
    }
}
