package edu.neu.ccs.cs5010;

import java.math.BigInteger;

//to save b and n because bank need a and n to verify the signature

public class RSAPublicKey {
    private BigInteger b;
    private BigInteger n;

    public RSAPublicKey(BigInteger b,BigInteger n){
        this.b = b;
        this.n = n;
    }

    public BigInteger getN() {
        return n;
    }

    public BigInteger getB() {
        return b;
    }
}


