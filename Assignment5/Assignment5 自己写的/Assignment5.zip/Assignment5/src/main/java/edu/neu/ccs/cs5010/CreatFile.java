package edu.neu.ccs.cs5010;

import java.math.BigInteger;
import java.time.LocalDateTime;

public class CreatFile {//have not finished yet because I didn't do assignmnent3 by mysefl so I'm not familiar with it

    private LocalDateTime transactionTime;

    public void creatFile(Double clientID, int message, BigInteger signmessage, String requestType){

    }
}
