package edu.neu.ccs.cs5010;

import org.junit.Test;

import static org.junit.Assert.*;

public class SignatureGenerationTest {
    @Test
    public void sign() throws Exception {
    }

}