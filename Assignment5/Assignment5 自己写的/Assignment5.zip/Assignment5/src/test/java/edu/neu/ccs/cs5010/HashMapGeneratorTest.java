package edu.neu.ccs.cs5010;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class HashMapGeneratorTest {
    private HashMapGenerator hashMapGenerator;
    @Before
    public void setUp() throws Exception {
        hashMapGenerator = new HashMapGenerator();
    }

    @Test
    public void creatMap() throws Exception {
    }

    @Test
    public void getPrivateKeyHashMap() throws Exception {
    }

    @Test
    public void getPublicKeyHashMap() throws Exception {
    }

}