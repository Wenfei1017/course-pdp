package edu.neu.ccs.cs5010;

import org.junit.Test;

import static org.junit.Assert.*;

public class RSAKeyPairTest {
    @Test
    public void getPrivateKey() throws Exception {
    }

    @Test
    public void getPublicKey() throws Exception {
    }

}