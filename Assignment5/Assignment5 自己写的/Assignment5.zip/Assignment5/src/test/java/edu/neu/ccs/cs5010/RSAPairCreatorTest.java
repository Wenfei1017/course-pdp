package edu.neu.ccs.cs5010;

import org.junit.Test;

import static org.junit.Assert.*;

public class RSAPairCreatorTest {
    @Test
    public void createKeys() throws Exception {
    }

}