package edu.neu.ccs.cs5010;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class FollowedGraphTest {
    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void createFollowedGraph() throws Exception {
    }

    @Test
    public void getVexNum() throws Exception {
    }

    @Test
    public void getEdgeNum() throws Exception {
    }

    @Test
    public void getVexElement() throws Exception {
    }

    @Test
    public void getVetexList() throws Exception {
    }

    @Test
    public void getIDNumber() throws Exception {
    }

    @Test
    public void printGraph() throws Exception {
    }

    @Test
    public void countFollowers() throws Exception {
    }

    @Test
    public void getfollowerList() throws Exception {
    }

}